/**
 * @file    main.cpp
 * @brief   Einstiegspunkt – Initialisierung und Task-Erstellung für das
 *          FreeRTOS-basierte Umgebungsüberwachungssystem.
 * @details Erstellt die globalen RTOS-Objekte (Queues, Event Group) sowie
 *          die vier Tasks ACQ / PROC / COMM / SUP und startet den Scheduler.
 *          Platform : Arduino Mega 2560 (ATmega2560, 16 MHz)
 *          RTOS     : FreeRTOS (feilipu/Arduino_FreeRTOS_Library)
 */


#include <Arduino.h>
#include <Arduino_FreeRTOS.h>
#include <queue.h>
#include <event_groups.h>

#include "task_acquisition.h"
#include "task_processing.h"
#include "task_comm.h"
#include "task_supervisor.h"

QueueHandle_t      xQueueRawData   = NULL;
QueueHandle_t      xQueueProcessed = NULL;
EventGroupHandle_t xEventAlive     = NULL;

#define STACK_ACQ   600
#define STACK_PROC  200
#define STACK_COMM  400
#define STACK_SUP   220   

extern "C" void vApplicationStackOverflowHook(TaskHandle_t xTask, char *pcTaskName)
{
    Serial.print(F("\r\n!!! STACK OVERFLOW in: "));
    Serial.println(pcTaskName);
    Serial.flush();
    for (;;) { ; }
}

static int freeRAM()
{
    extern char *__brkval;
    extern char  __heap_start;
    char top;
    return (int)&top - (int)(__brkval ? __brkval : &__heap_start);
}

void setup(void)
{
    Serial.begin(115200);
    while (!Serial) { ; }

    Serial.println(F("FreeRTOS - DHT11 + MQ-135 + I2C-LCD"));
    Serial.print(F("[main] RAM frei: "));
    Serial.println(freeRAM());

    acquisition_init();
    comm_init();

    xQueueRawData   = xQueueCreate(2, sizeof(sensor_data_t));
    xQueueProcessed = xQueueCreate(2, sizeof(processed_data_t));
    xEventAlive     = xEventGroupCreate();

    if (!xQueueRawData || !xQueueProcessed || !xEventAlive) {
        Serial.println(F("FATAL: Queue/Event NULL!"));
        for (;;) { ; }
    }

    BaseType_t ok;
    ok = xTaskCreate(vTaskAcquisition, "ACQ",  STACK_ACQ,  NULL, 3, NULL);
    Serial.println(ok == pdPASS ? F("[main] ACQ:  OK") : F("[main] ACQ:  FAIL!"));
    ok = xTaskCreate(vTaskProcessing,  "PROC", STACK_PROC, NULL, 2, NULL);
    Serial.println(ok == pdPASS ? F("[main] PROC: OK") : F("[main] PROC: FAIL!"));
    ok = xTaskCreate(vTaskComm,        "COMM", STACK_COMM, NULL, 1, NULL);
    Serial.println(ok == pdPASS ? F("[main] COMM: OK") : F("[main] COMM: FAIL!"));
    ok = xTaskCreate(vTaskSupervisor,  "SUP",  STACK_SUP,  NULL, 4, NULL);
    Serial.println(ok == pdPASS ? F("[main] SUP:  OK") : F("[main] SUP:  FAIL!"));

    Serial.println(F("[main] Scheduler startet..."));
    Serial.flush();
}

void loop(void) { }
