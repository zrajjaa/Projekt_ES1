/**
 * @file    task_processing.cpp
 * @brief   Datenverarbeitungs-Task – gleitender Mittelwert und Schwellwertprüfung.
 * @details Zykluszeit : event-driven (blockiert auf xQueueRawData)
 *          Priorität  : 2 (mittel)
 *          Filterung  : gleitender Mittelwert über die letzten 5 Messwerte
 *                       für Temperatur, Luftfeuchtigkeit UND Luftqualität.
 */

#include <Arduino.h>
#include <Arduino_FreeRTOS.h>
#include <queue.h>
#include <event_groups.h>

#include "task_acquisition.h"
#include "task_processing.h"
#include "task_supervisor.h"   // PIN_LED_TEMP, PIN_LED_HUM, PIN_LED_AQ

/* ---- Filterkonfiguration ------------------------------------------------ */
#define FILTER_SIZE  5

/* ---- Ringpuffer --------------------------------------------------------- */
static float    tempBuf[FILTER_SIZE];
static float    humBuf[FILTER_SIZE];
static float    aqBuf[FILTER_SIZE];   ///< MQ-135 ADC-Werte als float für Mittelwert
static uint8_t  bufIdx   = 0;
static uint8_t  bufCount = 0;

static float averageFloat(const float *buf, uint8_t count)
{
    float sum = 0.0f;
    for (uint8_t i = 0; i < count; i++) sum += buf[i];
    return sum / (float)count;
}

/* ========================================================================= */
void vTaskProcessing(void *pvParameters)
{
    (void)pvParameters;
    sensor_data_t    raw;
    processed_data_t proc;

    /* ---- Alarm-LEDs + Buzzer initialisieren ---------------------------- */
    pinMode(PIN_LED_TEMP, OUTPUT);  digitalWrite(PIN_LED_TEMP, LOW);
    pinMode(PIN_LED_HUM,  OUTPUT);  digitalWrite(PIN_LED_HUM,  LOW);
    pinMode(PIN_LED_AQ,   OUTPUT);  digitalWrite(PIN_LED_AQ,   LOW);
    pinMode(PIN_BUZZER,   OUTPUT);  digitalWrite(PIN_BUZZER,   LOW);

    for (;;) {
        if (xQueueReceive(xQueueRawData, &raw, portMAX_DELAY) == pdTRUE) {

            /* ---- Ringpuffer aktualisieren ------------------------------- */
            tempBuf[bufIdx] = raw.temperature;
            humBuf[bufIdx]  = raw.humidity;
            aqBuf[bufIdx]   = (float)raw.airQuality;   
            bufIdx          = (bufIdx + 1) % FILTER_SIZE;
            if (bufCount < FILTER_SIZE) bufCount++;

            /* ---- Mittelwerte berechnen ---------------------------------- */
            proc.tempFiltered = averageFloat(tempBuf, bufCount);
            proc.humFiltered  = averageFloat(humBuf,  bufCount);
            proc.aqFiltered   = averageFloat(aqBuf,   bufCount);
            proc.timestamp_ms = raw.timestamp_ms;

            /* ---- Schwellwertprüfung ------------------------------------- */
            proc.alertFlags = 0;

            if (proc.tempFiltered > THRESHOLD_TEMP_HIGH)
                proc.alertFlags |= ALERT_TEMP_HIGH;

            if (proc.humFiltered > THRESHOLD_HUM_HIGH)
                proc.alertFlags |= ALERT_HUM_HIGH;

            /* MQ-135: hoher ADC-Wert = schlechte Luft → Alarm */
            if (proc.aqFiltered > (float)THRESHOLD_AQ_HIGH)
                proc.alertFlags |= ALERT_AQ_HIGH;

            /* ---- Alarm-LEDs setzen ------------------------------------- */
            digitalWrite(PIN_LED_TEMP, (proc.alertFlags & ALERT_TEMP_HIGH) ? HIGH : LOW);
            digitalWrite(PIN_LED_HUM,  (proc.alertFlags & ALERT_HUM_HIGH)  ? HIGH : LOW);
            digitalWrite(PIN_LED_AQ,   (proc.alertFlags & ALERT_AQ_HIGH)   ? HIGH : LOW);

            /* ---- Buzzer: tone() bei Alarm, noTone() wenn OK ------------ */
            if (proc.alertFlags != 0) {
                tone(PIN_BUZZER, 1000);   // 1000 Hz – passiver Buzzer
            } else {
                noTone(PIN_BUZZER);
            }

            /* ---- Weiterleiten ------------------------------------------- */
            if (xQueueSend(xQueueProcessed, &proc, pdMS_TO_TICKS(50)) != pdTRUE) {
                processed_data_t dummy;
                xQueueReceive(xQueueProcessed, &dummy, 0);
                xQueueSend(xQueueProcessed, &proc, 0);
            }

            /* ---- Alive-Signal ------------------------------------------- */
            xEventGroupSetBits(xEventAlive, EVT_PROC_ALIVE);

            /* ---- Debug -------------------------------------------------- */
            if (proc.alertFlags != 0) {
                Serial.print(F("[PROC] ALARM! Flags=0x"));
                Serial.println(proc.alertFlags, HEX);
            }
        }
    }
}
