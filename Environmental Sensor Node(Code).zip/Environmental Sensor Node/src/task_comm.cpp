/**
 * @file    task_comm.cpp
 * @brief   Kommunikations-Task – LCD 1602 via I2C und UART-Ausgabe.
 * @details Zykluszeit : event-driven (blockiert auf xQueueProcessed)
 *          Priorität  : 1 (niedrig)
 *
 *          LCD 1602 mit I2C-Backpack (PCF8574):
 *            I2C-Adresse : 0x27  (häufigste Variante)
 *                          0x3F  (alternative Adresse – in comm_init() ändern)
 *            SDA = Pin 20 (Mega), SCL = Pin 21 (Mega)
 
 *
 *          LCD-Layout (16×2):
 *            Zeile 0: "T:xx.xC H:xx.x%"
 *            Zeile 1: "AQ:xxxx ST:[OK] "
 *                      AQ = MQ-135 ADC-Mittelwert (0-1023)
 *                      ST = Gesamtstatus
 *
 *          UART CSV-Format:
 *            timestamp_ms, temp_C, hum_pct, aq_raw, alerts
 */

#include <Arduino.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <Arduino_FreeRTOS.h>
#include <queue.h>
#include <event_groups.h>

#include "task_comm.h"
#include "task_acquisition.h"   
#include "task_processing.h"
#include "task_supervisor.h"

/* ---- I2C-Adresse des LCD-Backpacks -------------------------------------- */

#define LCD_I2C_ADDR  0x27
#define LCD_COLS      16
#define LCD_ROWS       2

/* LiquidCrystal_I2C(addr, cols, rows) */
static LiquidCrystal_I2C lcd(LCD_I2C_ADDR, LCD_COLS, LCD_ROWS);

/* ========================================================================= */
void comm_init(void)
{
    Wire.begin();            
    lcd.init();              
    lcd.backlight();        

    lcd.setCursor(0, 0);
    lcd.print(F("EnvNode"));
    lcd.setCursor(0, 1);
    lcd.print(F("Project-1"));

    Serial.println(F("[COMM] LCD 1602 init via I2C"));
    Serial.print  (F("[COMM] I2C-Adresse: 0x"));
    Serial.println(LCD_I2C_ADDR, HEX);
    Serial.println(F("[COMM] SDA=Pin20, SCL=Pin21 (Mega)"));
    Serial.println(F("\r\n--- CSV DATA BEGIN ---"));
    Serial.println(F("timestamp_ms,temp_C,hum_pct,aq_raw,alerts"));
}

/* ========================================================================= */
void vTaskComm(void *pvParameters)
{
    (void)pvParameters;
    processed_data_t data;

    char tmpStr[7];    
    char humStr[7];
    char aqStr[5];     

    for (;;) {
        if (xQueueReceive(xQueueProcessed, &data, portMAX_DELAY) == pdTRUE) {

            dtostrf(data.tempFiltered, 4, 1, tmpStr);  
            dtostrf(data.humFiltered,  4, 1, humStr);  

            
            uint16_t aqInt = (uint16_t)(data.aqFiltered + 0.5f);
            itoa(aqInt, aqStr, 10);


            lcd.setCursor(0, 0);
            lcd.print(F("T:"));
            lcd.print(tmpStr);
            lcd.print(F("C H:"));
            lcd.print(humStr);
            lcd.print('%');

            /* ═══ LCD Zeile 1: "AQ:xxxx ST:[OK] " ═══
             *     oder         "AQ:xxxx ST:[ALM]"     */
            lcd.setCursor(0, 1);
            lcd.print(F("AQ:"));

        
            uint8_t aqLen = strlen(aqStr);
            for (uint8_t i = aqLen; i < 4; i++) lcd.print(' ');
            lcd.print(aqStr);

            lcd.print(F(" ST:"));
            if (data.alertFlags != 0) {
                lcd.print(F("[ALM]"));
            } else {
                lcd.print(F("[OK] "));
            }

            /* ═══ UART CSV-Ausgabe ═══ */
            Serial.print(data.timestamp_ms);
            Serial.print(',');
            Serial.print(data.tempFiltered, 1);
            Serial.print(',');
            Serial.print(data.humFiltered, 1);
            Serial.print(',');
            Serial.print(aqInt);
            Serial.print(',');
            Serial.println(data.alertFlags, HEX);

            /* ---- Alive-Signal ------------------------------------------- */
            xEventGroupSetBits(xEventAlive, EVT_COMM_ALIVE);
        }
    }
}
