/**
 * @file    task_supervisor.cpp
 * @brief   Überwachungs-Task – prüft Task-Alive-Signale und Queue-Füllstände.
 * @details Zykluszeit : 5 000 ms (vTaskDelayUntil)
 *          Priorität  : 4 (höchste)
 */

#include <Arduino.h>
#include <Arduino_FreeRTOS.h>
#include <event_groups.h>
#include <queue.h>

#include "task_supervisor.h"
#include "task_acquisition.h"
#include "task_processing.h"

#define SUP_PERIOD_MS  5000
#define QUEUE_DEPTH    2


void vTaskSupervisor(void *pvParameters)
{
    (void)pvParameters;

    pinMode(PIN_LED_ERROR, OUTPUT);
    digitalWrite(PIN_LED_ERROR, LOW);
    vTaskDelay(pdMS_TO_TICKS(SUP_PERIOD_MS + 500));

    TickType_t xLastWakeTime = xTaskGetTickCount();
    uint32_t   cycleCount    = 0;

    for (;;) {
        cycleCount++;

    
        EventBits_t bits = xEventGroupWaitBits(
            xEventAlive, EVT_ALL_ALIVE, pdTRUE, pdFALSE, 0);

        bool allAlive = true;
        if (!(bits & EVT_ACQ_ALIVE)) {
            Serial.println(F("[SUP] WARN: ACQ fehlt!"));
            allAlive = false;
        }
        if (!(bits & EVT_PROC_ALIVE)) {
            Serial.println(F("[SUP] WARN: PROC fehlt!"));
            allAlive = false;
        }
        if (!(bits & EVT_COMM_ALIVE)) {
            Serial.println(F("[SUP] WARN: COMM fehlt!"));
            allAlive = false;
        }

        digitalWrite(PIN_LED_ERROR, allAlive ? LOW : HIGH);

        UBaseType_t rawUsed  = uxQueueMessagesWaiting(xQueueRawData);
        UBaseType_t procUsed = uxQueueMessagesWaiting(xQueueProcessed);

        Serial.print(F("[SUP] #"));
        Serial.print(cycleCount);
        Serial.print(allAlive ? F(" OK") : F(" ERR"));
        Serial.print(F(" Q:"));
        Serial.print(rawUsed);
        Serial.print('/');
        Serial.print(QUEUE_DEPTH);
        Serial.print(',');
        Serial.print(procUsed);
        Serial.print('/');
        Serial.print(QUEUE_DEPTH);
        Serial.print(F(" SUP-HWM="));
        Serial.print(uxTaskGetStackHighWaterMark(NULL));
        Serial.println(F("w"));

        vTaskDelayUntil(&xLastWakeTime, pdMS_TO_TICKS(SUP_PERIOD_MS));
    }
}