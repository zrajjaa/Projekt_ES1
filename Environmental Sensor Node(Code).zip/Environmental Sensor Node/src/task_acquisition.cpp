/**
 * @file    task_acquisition.cpp
 * @brief   Sensor-Erfassungs-Task für DHT11 + MQ-135.
 * @details Zykluszeit : 2 000 ms (vTaskDelayUntil)
 *          Priorität  : 3 (hoch – zeitkritische Erfassung)
 *          Kommunikation: sendet sensor_data_t in xQueueRawData
 *
 *          Hardware:
 *            - DHT11  an Digital-Pin 2  (Temp + Hum)
 *            - MQ-135 an Analog-Pin A0  (Luftqualität, AO-Ausgang)
 *
 *          MQ-135 Hinweis:
 *            Der Sensor braucht ~24–48 h Einbrennzeit für stabile Werte.
 *            Hier wird der rohe ADC-Wert (0–1023) übertragen.
 *            Höherer Wert = schlechtere Luftqualität / mehr Gas.
 */

#include <Arduino.h>
#include <DHT.h>
#include <Arduino_FreeRTOS.h>
#include <queue.h>
#include <event_groups.h>

#include "task_acquisition.h"
#include "task_supervisor.h"   // PIN_LED_HB

/* ---- Pin-Konfiguration -------------------------------------------------- */
#define DHT_PIN        2        ///< DHT11 Datenpin
#define DHT_TYPE       DHT11
#define MQ135_PIN      A0       ///< MQ-135 Analog-Ausgang (AO)

#define ACQ_PERIOD_MS  2000     ///< Messintervall in ms

static DHT dht(DHT_PIN, DHT_TYPE);

/* ========================================================================= */
void acquisition_init(void)
{
    /* DHT11 */
    dht.begin();
    Serial.println(F("[ACQ] DHT11 initialisiert (Pin 2)"));
    Serial.println(F("[ACQ] HINWEIS: DHT11 Genauigkeit: Temp ±2°C, Hum ±5%"));

    /* MQ-135 */
    Serial.println(F("[ACQ] MQ-135 initialisiert (Pin A0)"));
    Serial.println(F("[ACQ] HINWEIS: MQ-135 braucht ~24h Einbrennzeit!"));

    /* Heartbeat-LED */
    pinMode(PIN_LED_HB, OUTPUT);
    digitalWrite(PIN_LED_HB, LOW);
    Serial.println(F("[ACQ] Heartbeat-LED Pin 7"));
}

/* ========================================================================= */
void vTaskAcquisition(void *pvParameters)
{
    (void)pvParameters;
    sensor_data_t sample;

    /* ── DHT11 + MQ-135 Aufwärmzeit ── */
    vTaskDelay(pdMS_TO_TICKS(2000));

 
    TickType_t xLastWakeTime = xTaskGetTickCount();

    for (;;) {
        float t, h;
        uint16_t aq;


        vTaskSuspendAll();
        t  = dht.readTemperature();
        h  = dht.readHumidity();
        aq = (uint16_t)analogRead(MQ135_PIN);
        xTaskResumeAll();

        /* ── NaN-Retry für DHT11 (MQ-135 liefert immer einen Wert) ── */
        if (isnan(t) || isnan(h)) {
            vTaskDelay(pdMS_TO_TICKS(200));

            vTaskSuspendAll();
            t = dht.readTemperature(false, true);   // force=true
            h = dht.readHumidity(true);             // force=true
            xTaskResumeAll();
        }

        sample.temperature  = isnan(t) ? -99.0f : t;
        sample.humidity     = isnan(h) ? -1.0f  : h;
        sample.airQuality   = aq;
        sample.timestamp_ms = millis();

        /* ---- Queue senden (neuester Wert hat Vorrang) --------------- */
        if (xQueueSend(xQueueRawData, &sample, 0) != pdTRUE) {
            sensor_data_t dummy;
            xQueueReceive(xQueueRawData, &dummy, 0);
            xQueueSend(xQueueRawData, &sample, 0);
        }

        /* ---- Alive-Signal ------------------------------------------- */
        xEventGroupSetBits(xEventAlive, EVT_ACQ_ALIVE);

        /* ---- Heartbeat-LED toggeln (sichtbar alle 2 s) -------------- */
        digitalWrite(PIN_LED_HB, !digitalRead(PIN_LED_HB));

        /* ---- Debug auf UART ----------------------------------------- */
        Serial.print(F("[ACQ] "));
        Serial.print(sample.temperature, 1);
        Serial.print(F("C "));
        Serial.print(sample.humidity, 1);
        Serial.print(F("% AQ="));
        Serial.print(sample.airQuality);
        Serial.print(F(" @"));
        Serial.println(sample.timestamp_ms);

        /* ---- Nächste Periode ---------------------------------------- */
        vTaskDelayUntil(&xLastWakeTime, pdMS_TO_TICKS(ACQ_PERIOD_MS));
    }
}
