#pragma once

/**
 * @file    task_comm.h
 * @brief   Schnittstelle für den Kommunikations-Task.
 * @details LCD 1602 via I2C (PCF8574 Backpack).
 *          UART: CSV-Ausgabe mit Luftqualitätsspalte.
 */

void comm_init(void);
void vTaskComm(void *pvParameters);
