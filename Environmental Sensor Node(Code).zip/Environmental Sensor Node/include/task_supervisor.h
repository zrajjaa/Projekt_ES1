#pragma once

/**
 * @file    task_supervisor.h
 * @brief   Schnittstelle für den Überwachungs-Task.
 */

#include <Arduino_FreeRTOS.h>
#include <event_groups.h>

/* ===== Alive-Event-Bits ================================================== */
#define EVT_ACQ_ALIVE   (1 << 0)
#define EVT_PROC_ALIVE  (1 << 1)
#define EVT_COMM_ALIVE  (1 << 2)
#define EVT_ALL_ALIVE   (EVT_ACQ_ALIVE | EVT_PROC_ALIVE | EVT_COMM_ALIVE)

/* ===== GPIO ============================================================== */
#define PIN_LED_ERROR   13
#define PIN_LED_HB       7
#define PIN_LED_TEMP     8
#define PIN_LED_HUM      9
#define PIN_LED_AQ      10
#define PIN_BUZZER      11  

/* ===== API =============================================================== */
void vTaskSupervisor(void *pvParameters);
