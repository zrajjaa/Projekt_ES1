#pragma once

/**
 * @file    task_acquisition.h
 * @brief   Schnittstelle für den Erfassungs-Task.
 * @details Sensoren:
 *            - DHT11  : Temperatur + Luftfeuchtigkeit  (Digital-Pin 2)
 *            - MQ-135 : Luftqualität / CO₂-Indikator   (Analog-Pin A0)
 */

#include <Arduino_FreeRTOS.h>
#include <queue.h>
#include <event_groups.h>

/* ===== Globale RTOS-Objekte (definiert in main.cpp) ====================== */
extern QueueHandle_t      xQueueRawData;
extern QueueHandle_t      xQueueProcessed;
extern EventGroupHandle_t xEventAlive;

/* ===== Rohdaten-Struktur ================================================= */
typedef struct {
    float    temperature;   ///< DHT11 Temperatur in °C  
    float    humidity;      ///< DHT11 Luftfeuchte in %  
    uint16_t airQuality;    ///< MQ-135 ADC-Rohwert 0-1023 (höher = schlechter)
    uint32_t timestamp_ms;  ///< millis() zum Messzeitpunkt
} sensor_data_t;

/* ===== API =============================================================== */
void acquisition_init(void);
void vTaskAcquisition(void *pvParameters);
