#pragma once

/**
 * @file    task_processing.h
 * @brief   Schnittstelle für den Verarbeitungs-Task.
 */

/* ===== Verarbeitete Daten-Struktur ======================================= */
typedef struct {
    float    tempFiltered;  ///< Gefilterter Temperatur-Mittelwert in °C
    float    humFiltered;   ///< Gefilterter Feuchte-Mittelwert in %
    float    aqFiltered;    ///< Gefilterter MQ-135-ADC-Mittelwert (0–1023)
    uint32_t timestamp_ms;  ///< Zeitstempel der letzten Rohmessung
    uint8_t  alertFlags;    ///< Bit-Flags (siehe ALERT_* unten)
} processed_data_t;

/* ===== Alarm-Flags ======================================================= */
#define ALERT_TEMP_HIGH  (1 << 0)   ///< Temperatur über Grenzwert
#define ALERT_HUM_HIGH   (1 << 1)   ///< Luftfeuchtigkeit über Grenzwert
#define ALERT_AQ_HIGH    (1 << 2)   ///< Luftqualität unter Grenzwert (ADC > Schwelle)

/* ===== Schwellwerte ====================================================== */
#define THRESHOLD_TEMP_HIGH   30.0f   ///< °C – Temperaturalarm ab 30 °C
#define THRESHOLD_HUM_HIGH    80.0f   ///< %  – Feuchtalarm ab 80 %
#define THRESHOLD_AQ_HIGH    600U     ///< ADC-Rohwert – Luftqualitätsalarm (0–1023)
                                      ///< ~600 entspricht mäßiger Luftqualität;
                                      ///< bei kalibrierten Werten anpassen!

/* ===== API =============================================================== */
void vTaskProcessing(void *pvParameters);
