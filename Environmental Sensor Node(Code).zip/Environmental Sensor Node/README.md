# Project 1: Real-Time Environmental Monitoring Node

## Übersicht

Echtzeit-Umweltsensorknoten auf Arduino Mega 2560 mit FreeRTOS.
Erfasst Temperatur, Luftfeuchtigkeit und Luftqualität, verarbeitet die
Messwerte mit einem gleitenden Mittelwert und gibt sie auf LCD und UART aus.
Alarme werden durch LEDs und einen Buzzer signalisiert.

## Hardware

| Komponente   | Modul              | Anschluss            |
|--------------|--------------------|----------------------|
| MCU          | Mega 2560          | –                    |
| Temp/Hum     | DHT11              | Digital Pin 2        |
| Luftqualität | MQ-135             | Analog A0            |
| Display      | LCD 1602 I2C       | I2C (SDA=20, SCL=21) |
| Heartbeat    | LED grün + 220 Ω   | Pin 7                |
| Temp-Alarm   | LED rot + 220 Ω    | Pin 8                |
| Hum-Alarm    | LED gelb + 220 Ω   | Pin 9                |
| AQ-Alarm     | LED blau + 220 Ω   | Pin 10               |
| Buzzer       | Passiv + PN2222    | Pin 11               |
| SUP-Fehler   | LED (Onboard)      | Pin 13               |

## Verkabelung

```
DHT11:    VCC→5V   GND→GND   DATA→Pin2   (10kΩ Pull-up empfohlen)
MQ-135:   VCC→5V   GND→GND   AOUT→A0
LCD I2C:  VCC→5V   GND→GND   SDA→Pin20   SCL→Pin21
LEDs:     Pin7/8/9/10/13 → 220Ω → LED(+) → LED(-) → GND
Buzzer:   Pin11 → 1kΩ → PN2222(B) | PN2222(C)→Buzzer(-) | PN2222(E)→GND | Buzzer(+)→5V
```

## Build & Flash

```bash
pio run                    # Kompilieren
pio run --target upload    # Flashen
pio device monitor         # Serial Monitor (115200 Baud)
pio run --target clean     # Cache löschen
```

## FreeRTOS Tasks

| Task          | Priorität | Periode      | Funktion                                  |
|---------------|-----------|--------------|-------------------------------------------|
| Supervisor    | 4         | 5 000 ms     | Alive-Check, Fehler-LED (Pin 13)          |
| Acquisition   | 3         | 2 000 ms     | DHT11 + MQ-135, Heartbeat-LED (Pin 7)     |
| Processing    | 2         | event-driven | Filter + Schwellwert + LEDs + Buzzer      |
| Communication | 1         | event-driven | LCD + UART CSV                            |

## LED & Buzzer Verhalten

| Komponente | Pin | Verhalten                              |
|------------|-----|----------------------------------------|
| Heartbeat  |  7  | Toggelt alle 2 s – System läuft        |
| Temp-LED   |  8  | AN wenn Temp > 30 °C                   |
| Hum-LED    |  9  | AN wenn Hum > 80 %                     |
| AQ-LED     | 10  | AN wenn AQ-ADC > 600                   |
| Buzzer     | 11  | 1000 Hz Ton bei beliebigem Alarm       |
| Fehler-LED | 13  | AN wenn ein Task nicht antwortet       |

## UART CSV-Format

```
timestamp_ms,temp_C,hum_pct,aq_raw,alerts
2001,22.5,48.3,180,0
4002,22.6,48.1,185,0
6003,36.1,82.0,650,7    ← Alle Alarme aktiv (0x07)
```

## Dokumentation

Siehe [DESIGN.md](DESIGN.md) für Architektur und Scheduling-Analyse.
