# DESIGN.md – Project 1: Real-Time Environmental Monitoring Node

## 1. Projektübersicht

Dieses Projekt implementiert einen Echtzeit-Umweltsensorknoten auf einem
**Arduino Mega 2560** (ATmega2560, 16 MHz) unter Verwendung von **FreeRTOS**.

Das System erfasst periodisch Temperatur, Luftfeuchtigkeit und Luftqualität,
verarbeitet die Daten mit einem gleitenden Mittelwert, zeigt sie auf einem
LCD an und gibt sie über UART im CSV-Format aus.

### Verwendete Hardware
┌─────────────────────────────────────────────────────────────────────────┐
| Komponente         | Typ / Modul        | Schnittstelle | Adresse / Pin |
|--------------------|--------------------|---------------|---------------|
| Mikrocontroller    | Arduino Mega 2560  | –             | –             |
| Temp/Hum-Sensor    | DHT11              | Digital       | Pin 2         |
| Luftqualitätssensor| MQ-135             | ADC (analog)  | A0            |
| Display            | LCD 1602 + PCF8574 | I2C           | 0x27          |
| Heartbeat-LED      | LED grün + 220 Ω   | GPIO          | Pin 7         |
| Temp-Alarm-LED     | LED rot + 220 Ω    | GPIO          | Pin 8         |
| Hum-Alarm-LED      | LED gelb + 220 Ω   | GPIO          | Pin 9         |
| AQ-Alarm-LED       | LED blau + 220 Ω   | GPIO          | Pin 10        |
| Passiver Buzzer    | Buzzer + PN2222    | GPIO (PWM)    | Pin 11        |
| Status-LED         | On-Board LED       | GPIO          | Pin 13        |
└─────────────────────────────────────────────────────────────────────────┘
---

## 2. Architektur

### 2.1 Task-Übersicht
┌────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┐
| Taskname      | Periode     | Priorität  | Stack (Bytes) | Typ           | Beschreibung                                    |
|---------------|-------------|------------|---------------|---------------|------------------------------------------------ |
| Acquisition   | 2 000 ms    | 3 (hoch)   | 600           | Periodisch    | DHT11 + MQ-135 auslesen, Heartbeat-LED toggle   |
| Processing    | event-driven| 2 (mittel) | 250           | Event-driven  | Filter + Schwellwertprüfung + LEDs + Buzzer     |
| Communication | event-driven| 1 (niedrig)| 400           | Event-driven  | LCD-Ausgabe + UART-CSV-Logging                  |
| Supervisor    | 5 000 ms    | 4 (höchste)| 220           | Periodisch    | Alive-Check, Queue-Monitoring, Fehler-LED       |
└────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────┘
### 2.2 RTOS-Objekte
┌─────────────────────────────────────────────────────────────────────────────────────┐
| Objekt             | Typ                | Zweck                                     |
|--------------------|--------------------|-------------------------------------------|
| xQueueRawData      | Queue (2 Elemente) | Rohdaten: Acquisition → Processing        |
| xQueueProcessed    | Queue (2 Elemente) | Verarbeitete Daten: Processing → Comm     |
| xEventAlive        | Event Group        | Alive-Signale aller Tasks an Supervisor   |
└─────────────────────────────────────────────────────────────────────────────────────┘
---

## 3. Scheduling-Analyse

### 3.1 Prioritätsbegründung

**Supervisor (Prio 4, höchste):** Die Systemüberwachung muss jederzeit
preemptiv auf Fehler reagieren können. Kurze Laufzeit, daher blockiert sie
andere Tasks nur minimal.

**Acquisition (Prio 3):** Die Sensorerfassung ist zeitkritisch und muss
ihre 2-Sekunden-Deadline einhalten, um deterministische Abtastung zu
gewährleisten. Höher als Processing und Comm, damit Daten zuverlässig
erfasst werden.

**Processing (Prio 2):** Die Datenverarbeitung ist wichtiger als die Anzeige,
aber weniger zeitkritisch als die Erfassung. Blockiert auf der Queue und
wird nur aktiv, wenn neue Daten vorliegen. Setzt nach der Schwellwertprüfung
sofort die Alarm-LEDs (Pin 8/9/10) und steuert den Buzzer (Pin 11):
`tone(1000 Hz)` bei Alarm, `noTone()` wenn alle Werte im Normalbereich.

**Communication (Prio 1, niedrigste):** Die Anzeige auf LCD und UART ist
die am wenigsten zeitkritische Aufgabe. Eine leichte Verzögerung in der
Darstellung ist akzeptabel.

### 3.2 Kritische vs. unkritische Tasks

- **Kritisch:** Acquisition (feste Deadline 2 s), Supervisor (Fehlerüberwachung)
- **Unkritisch:** Communication (Verzögerung < 500 ms akzeptabel)
- **Mittel:** Processing (sollte vor nächster Acquisition fertig sein)

### 3.3 Periodische vs. Event-driven Tasks

- **Periodisch:** Acquisition (2 000 ms), Supervisor (5 000 ms)
  → Verwenden `vTaskDelayUntil()` für jitterfreie Perioden.
- **Event-driven:** Processing, Communication
  → Blockieren auf `xQueueReceive(..., portMAX_DELAY)` und werden nur
  bei neuen Daten geweckt.

### 3.4 Deadline-Analyse

```
Acquisition:  Deadline = 2 000 ms (muss vor nächster Periode fertig sein)
              WCET ≈ 15 ms (I2C-Lesevorgang + ADC-Lesen)
              → Auslastung: 15/2000 = 0,75 %

Processing:   Deadline = vor nächster Acquisition (< 2 000 ms)
              WCET ≈ 2 ms (Filterberechnung + LED + tone())
              → Auslastung: 2/2000 = 0,10 %

Communication: Deadline = vor nächster Datenlieferung (< 2 000 ms)
               WCET ≈ 30 ms (LCD-I2C-Schreibzugriff + UART)
               → Auslastung: 30/2000 = 1,5 %

Supervisor:   Deadline = 5 000 ms
              WCET ≈ 2 ms
              → Auslastung: 2/5000 = 0,04 %

Gesamtauslastung: ≈ 2,54 %  →  System ist weit unter der Auslastungsgrenze.
```

### 3.5 Preemption-Verhalten

Das System nutzt **preemptives Scheduling** (`configUSE_PREEMPTION = 1`).
Der Supervisor-Task (Prio 4) kann jeden anderen Task unterbrechen.
Der Acquisition-Task (Prio 3) kann Processing und Communication unterbrechen.
In der Praxis kommt es selten zu Preemption, da die meisten Tasks die meiste
Zeit in blockiertem Zustand verbringen (Queue-Wait oder vTaskDelayUntil).

---

## 4. Kommunikationsdiagramme

### 4.1 Task-Interaktionsdiagramm

```
 ┌───────────────────┐
 │   Supervisor      │  Prio 4, 5s Periode
 │   (Task 4)        │ 
 └───────▲───────────┘
         | xEventAlive (Event Group)
         | EVT_ACQ_ALIVE | EVT_PROC_ALIVE | EVT_COMM_ALIVE
         |
 ┌───────|──────┐     xQueueRawData             ┌───────────────────────┐
 │ Acquisition  │ ─────────────────────►        │  Processing           │
 │  (Task 1)    │     Queue (2 Elemente)        │  (Task 2)             │
 │  Prio 3      │                               │  Prio 2               │
 └──────┬───────┘                               └──────┬────────────────┘
          │                                            │
          │  toggle LED_HB (Pin 7)                     │ set LED_TEMP (Pin 8)
          │                                            │ set LED_HUM  (Pin 9)
          │                                            │ set LED_AQ   (Pin 10)
          │                                            │ tone()/noTone() (Pin 11)
          │                                            │
          │                                            │ xQueueProcessed
          │                                            │ Queue (2 Elemente)
          │           ┌───────────────┐                │
          └───────►   │Communication  │◄───────────────┘
          └───────►   │Communication  │
                      │  (Task 3)     │
                      │  Prio 1       │
                      └────┬──────────┘
                           │
                    ┌──────┴───────┐
                    │  LCD 1602    │  UART Serial
                    │  (I2C 0x27)  │  (115200 Baud)
                    └──────────────┘
```

### 4.2 Zeitablaufdiagramm (10 Sekunden)

```
Zeit (ms)  0    1000   2000   3000   4000   5000   6000   7000   8000   9000  10000
           │      │      │      │      │      │      │      │      │      │      │
ACQ(P3)    ██           ██           ██           ██           ██           ██
           │            │            │            │            │            │
PROC(P2)    █            █            █            █            █            █
            │            │            │            │            │            │
COMM(P1)     █            █            █            █            █            █
             │            │            │            │            │            │
SUP(P4)    █                                █                                █
           │                                │                                │
           ▼                                ▼                                ▼
         t=0                              t=5000                          t=10000

██ = Task läuft (stark vergrößert, tatsächlich < 30ms)
Leere Bereiche = Tasks im blockierten Zustand (Idle-Task läuft)
```

### 4.3 Datenflussdiagramm

```
 DHT11 (Digital Pin 2)         MQ-135 (ADC A0)
     │                               │ 
     └───────┬───────────────────────┘
             ▼
    ┌──────────────────┐
    │   Acquisition    │   sensor_data_t {temp, hum, airQ, ts}
    │   Task (Prio 3)  │──► LED_HB toggle (Pin 7)
    └────────┬─────────┘
             │ xQueueRawData
             ▼
    ┌──────────────────┐
    │   Processing     │   Gleitender Mittelwert (N=5)
    │   Task (Prio 2)  │   Schwellwertprüfung
    │                  │──► LED_TEMP (Pin 8) HIGH/LOW
    │                  │──► LED_HUM  (Pin 9) HIGH/LOW
    │                  │──► LED_AQ   (Pin 10) HIGH/LOW
    │                  │──► Buzzer tone(1000Hz)/noTone (Pin 11)
    └────────┬─────────┘
                │ xQueueProcessed
                ▼
    ┌──────────────────┐
    │  Communication   │   processed_data_t {tempF, humF, airQF, ts, alerts}
    │  Task (Prio 1)   │
    └───────┬──┬───────┘
            │  │
            │  └──► UART Serial (CSV, 115200 Baud)
            │
            ──► LCD 1602 I2C (0x27)
                Zeile 0: "T:xx.xC H:xx.x%"
                Zeile 1: "AQ:xxxx ST:[OK/ALM]"
```

---

## 5. Hardwareaufbau (Verkabelung)

### 5.1 DHT11 → Arduino Mega 2560
┌──────────────────────────────────────────────────────┐
| DHT11 Pin | Mega Pin | Beschreibung                  |
|-----------|----------|------------------------------ |
| VCC       | 3.3V     | Versorgungsspannung 3.3V      |
| GND       | GND      | Masse                         |
| SDA       | Pin 20   | I2C Daten                     |
| SCL       | Pin 21   | I2C Takt                      |
└──────────────────────────────────────────────────────┘
**Wichtig:** DHT11 arbeitet mit 3.3V Logik. Der Mega 2560 hat 5V I2C.
Für Produktionseinsatz wird ein Level-Shifter empfohlen. Für das Praktikum
funktioniert es meist direkt, da der DHT11 5V-tolerant ist.

### 5.2 MQ-135 → Arduino Mega 2560
┌─────────────────────────────────────────────────────┐
| MQ-135 Pin | Mega Pin | Beschreibung                |
|------------|----------|-----------------------------|
| VCC        | 5V       | Versorgungsspannung 5V      |
| GND        | GND      | Masse                       |
| AOUT       | A0       | Analogausgang               |
└─────────────────────────────────────────────────────┘
**Hinweis:** Der MQ-135 benötigt ca. 24 Stunden Aufwärmzeit, um genaue
Werte zu liefern. Für das Praktikum kann man direkt mit den ADC-Rohwerten
arbeiten.

### 5.3 LCD 1602 I2C → Arduino Mega 2560
┌───────────────────────────────────────────────────┐
| LCD I2C Pin | Mega Pin | Beschreibung             |
|-------------|----------|--------------------------|
| VCC         | 5V       | Versorgungsspannung 5V   |
| GND         | GND      | Masse                    |
| SDA         | Pin 20   | I2C Daten (gleicher Bus) |
| SCL         | Pin 21   | I2C Takt (gleicher Bus)  |
└───────────────────────────────────────────────────┘
### 5.4 Passiver Buzzer → Arduino Mega 2560 (via PN2222)
┌─────────────────────────────────────────────────────────────────────────────────────────────────────┐
| Bauteil                      | Anschluss                     | Beschreibung                         |
|------------------------------|-------------------------------|------------------------------------  |
| Arduino Pin 11               | 1kΩ → PN2222 Basis (B, mitte) |PWM-Signal (tone())                   |
| PN2222 Kollektor (C, rechts) | Buzzer (–) schwarz            | Schaltausgang                        |
| PN2222 Emitter (E, links)    | GND                           | Masse                                |
| Buzzer (+) rot               | Arduino 5V                    | Versorgungsspannung                  |
└─────────────────────────────────────────────────────────────────────────────────────────────────────┘
**Hinweis:** Der passive Buzzer benötigt ein PWM-Signal (`tone()`).
`digitalWrite(HIGH)` allein erzeugt keinen Ton – das funktioniert nur
beim aktiven Buzzer. Pin 11 des Mega ist PWM-fähig und kompatibel mit `tone()`.

### 5.5 Verkabelungsschema

```
                    Arduino Mega 2560
                ┌──────────────────────┐
                │                      │
   DHT11        │          Pin 20 (SDA)│◄────────── SDA (DHT11 + LCD)
   ┌────┐       │          Pin 21 (SCL)│◄────────── SCL (DHT11 + LCD)
   │VCC ├───3.3V│                      │
   │GND ├───GND │                Pin A0│◄────────── AOUT (MQ-135)
   │SDA ├───┐   │                      │
   │SCL |──┐│   │                    5V│◄────────── VCC (LCD + MQ-135)
   └────┘  ││   │                   GND│◄────────── GND (alle)
           ││   │                      │
   LCD     ││   │          Pin 13 (LED)│◄────────── Status-LED (on-board)
   ┌────┐  ││   │                      │
   │VCC ├──5V   │                   USB│◄────────── PC (Serial Monitor)
   │GND ├──GND  │                      │
   │SDA ├──┘│   └──────────────────────┘
   │SCL ├───┘
   └────┘

   MQ-135
   ┌─────┐
   │VCC  ├── 5V
   │GND  |── GND
   │AOUT ├── A0
   └─────┘
```

**I2C Pull-Up-Widerstände:** Der Arduino Mega hat interne Pull-Ups auf
den I2C-Leitungen. Externe 4.7kΩ Pull-Ups sind empfehlenswert, aber für
kurze Kabel auf dem Breadboard meist nicht notwendig.

---

## 6. Softwarearchitektur

### 6.1 Projektstruktur

```
project1/
├── README.md              ← Kurzbeschreibung, Build-Anleitung
├── DESIGN.md              ← Dieses Dokument
├── platformio.ini         ← PlatformIO-Konfiguration
├── include/
│   ├── task_acquisition.h ← Header: Sensorerfassung
│   ├── task_processing.h  ← Header: Datenverarbeitung
│   ├── task_comm.h        ← Header: Kommunikation (LCD + UART)
│   └── task_supervisor.h  ← Header: Überwachung
├── src/
│   ├── main.cpp           ← Setup, RTOS-Objekte, Task-Erstellung
│   ├── task_acquisition.cpp
│   ├── task_processing.cpp
│   ├── task_comm.cpp
│   └── task_supervisor.cpp
├── diagrams/              ← Diagramme (siehe oben)
└── build/                 ← PlatformIO Build-Output (automatisch)
```

### 6.2 Verwendete FreeRTOS-Mechanismen

1. **Queues** (xQueueRawData, xQueueProcessed): Nachrichtenübergabe zwischen Tasks
2. **Event Groups** (xEventAlive): Alive-Signale für den Supervisor
3. **vTaskDelayUntil**: Deterministische periodische Ausführung
4. **vTaskSuspendAll/xTaskResumeAll**: Scheduler-Pause für DHT11-Lesevorgang (kein taskENTER_CRITICAL – DHT11 benötigt Interrupts!)
5. **tone() / noTone()**: Arduino-PWM-Funktion für passiven Buzzer (kein FreeRTOS-Objekt, aber taskkompatibel auf Pin 11)

### 6.3 Fehlerbehandlung

- **DHT11 nicht gefunden:** Fehlerwerte (-99°C / -1%) werden gemeldet
- **Queue voll:** Ältester Eintrag wird verworfen (kein Datenverlust durch Blockierung)
- **I2C Mutex Timeout:** Fehler wird geloggt, Task fährt fort
- **Task reagiert nicht:** Supervisor schaltet LED an und meldet über UART

---

## 7. Build- und Flash-Anleitung

Siehe README.md für vollständige Schritt-für-Schritt-Anleitung.

```bash
# Kompilieren
pio run

# Flash
pio run --target upload

# Serial Monitor
pio device monitor
```
